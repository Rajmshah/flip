﻿
sliderJS = [{
  "template": {
    "type": "image",
    "content": "files/page/1.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 0,
    "name": "1",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/1.jpg"
  },
  "large": {
    "content": "files/large/1.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/2.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 1,
    "name": "2",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/2.jpg"
  },
  "large": {
    "content": "files/large/2.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/3.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 2,
    "name": "3",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/3.jpg"
  },
  "large": {
    "content": "files/large/3.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/4.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 3,
    "name": "4",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/4.jpg"
  },
  "large": {
    "content": "files/large/4.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/5.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 4,
    "name": "5",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/5.jpg"
  },
  "large": {
    "content": "files/large/5.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/6.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 5,
    "name": "6",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/6.jpg"
  },
  "large": {
    "content": "files/large/6.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/7.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 6,
    "name": "7",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/7.jpg"
  },
  "large": {
    "content": "files/large/7.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/8.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 7,
    "name": "8",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/8.jpg"
  },
  "large": {
    "content": "files/large/8.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/9.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 8,
    "name": "9",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/9.jpg"
  },
  "large": {
    "content": "files/large/9.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/10.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 9,
    "name": "10",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/10.jpg"
  },
  "large": {
    "content": "files/large/10.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/11.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 10,
    "name": "11",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/11.jpg"
  },
  "large": {
    "content": "files/large/11.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/12.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 11,
    "name": "12",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/12.jpg"
  },
  "large": {
    "content": "files/large/12.jpg"
  },
  "elements": []
},{
  "template": {
    "type": "image",
    "content": "files/page/13.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 12,
    "name": "13",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/13.jpg"
  },
  "large": {
    "content": "files/large/13.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/14.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 13,
    "name": "14",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/14.jpg"
  },
  "large": {
    "content": "files/large/14.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/15.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 14,
    "name": "15",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/15.jpg"
  },
  "large": {
    "content": "files/large/15.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/16.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 15,
    "name": "16",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/16.jpg"
  },
  "large": {
    "content": "files/large/16.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/17.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 16,
    "name": "17",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/17.jpg"
  },
  "large": {
    "content": "files/large/17.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/18.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 17,
    "name": "18",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/18.jpg"
  },
  "large": {
    "content": "files/large/18.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/19.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 120,
    "name": "19",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/19.jpg"
  },
  "large": {
    "content": "files/large/19.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/20.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 19,
    "name": "20",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/20.jpg"
  },
  "large": {
    "content": "files/large/20.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/21.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 20,
    "name": "21",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/21.jpg"
  },
  "large": {
    "content": "files/large/21.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/22.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 21,
    "name": "22",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/22.jpg"
  },
  "large": {
    "content": "files/large/22.jpg"
  },
  "elements": []
}, {
  "template": {
    "type": "image",
    "content": "files/page/23.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 22,
    "name": "23",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/23.jpg"
  },
  "large": {
    "content": "files/large/23.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/24.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 23,
    "name": "24",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/24.jpg"
  },
  "large": {
    "content": "files/large/24.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/25.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 24,
    "name": "25",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/25.jpg"
  },
  "large": {
    "content": "files/large/25.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/26.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 25,
    "name": "26",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/26.jpg"
  },
  "large": {
    "content": "files/large/26.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/27.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 26,
    "name": "27",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/27.jpg"
  },
  "large": {
    "content": "files/large/27.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/28.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 27,
    "name": "28",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/28.jpg"
  },
  "large": {
    "content": "files/large/28.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/29.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 28,
    "name": "29",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/29.jpg"
  },
  "large": {
    "content": "files/large/29.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/30.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 29,
    "name": "30",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/30.jpg"
  },
  "large": {
    "content": "files/large/30.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/31.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 30,
    "name": "31",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/31.jpg"
  },
  "large": {
    "content": "files/large/31.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/32.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 31,
    "name": "32",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/32.jpg"
  },
  "large": {
    "content": "files/large/32.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/33.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 32,
    "name": "33",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/33.jpg"
  },
  "large": {
    "content": "files/large/33.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/34.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 33,
    "name": "34",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/34.jpg"
  },
  "large": {
    "content": "files/large/34.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/35.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 34,
    "name": "35",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/35.jpg"
  },
  "large": {
    "content": "files/large/35.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/36.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 35,
    "name": "36",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/30.jpg"
  },
  "large": {
    "content": "files/large/30.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/37.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 36,
    "name": "37",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/37.jpg"
  },
  "large": {
    "content": "files/large/37.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/38.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 37,
    "name": "38",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/38.jpg"
  },
  "large": {
    "content": "files/large/38.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/39.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 38,
    "name": "39",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/39.jpg"
  },
  "large": {
    "content": "files/large/39.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/40.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 39,
    "name": "40",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/40.jpg"
  },
  "large": {
    "content": "files/large/40.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/41.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 40,
    "name": "41",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/41.jpg"
  },
  "large": {
    "content": "files/large/41.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/42.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 41,
    "name": "42",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/42.jpg"
  },
  "large": {
    "content": "files/large/42.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/43.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 42,
    "name": "43",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/43.jpg"
  },
  "large": {
    "content": "files/large/43.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/44.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 43,
    "name": "44",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/44.jpg"
  },
  "large": {
    "content": "files/large/44.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/45.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 44,
    "name": "45",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/45.jpg"
  },
  "large": {
    "content": "files/large/45.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/46.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 45,
    "name": "46",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/46.jpg"
  },
  "large": {
    "content": "files/large/46.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/47.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 46,
    "name": "47",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/47.jpg"
  },
  "large": {
    "content": "files/large/47.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/48.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 47,
    "name": "48",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/48.jpg"
  },
  "large": {
    "content": "files/large/48.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/49.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 48,
    "name": "49",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/49.jpg"
  },
  "large": {
    "content": "files/large/49.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/50.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 49,
    "name": "50",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/50.jpg"
  },
  "large": {
    "content": "files/large/50.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/51.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 50,
    "name": "51",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/51.jpg"
  },
  "large": {
    "content": "files/large/51.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/52.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 51,
    "name": "52",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/52.jpg"
  },
  "large": {
    "content": "files/large/52.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/53.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 52,
    "name": "53",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/53.jpg"
  },
  "large": {
    "content": "files/large/53.jpg"
  },
  "elements": []
},
{
  "template": {
    "type": "image",
    "content": "files/page/54.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 53,
    "name": "54",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/54.jpg"
  },
  "large": {
    "content": "files/large/54.jpg"
  },
  "elements": []
},{
  "template": {
    "type": "image",
    "content": "files/page/55.jpg"
  },
  "pluginsConfig": {
    "enableProgressBar": false
  },
  "info": {
    "id": 54,
    "name": "55",
    "width": 4134,
    "height": 5847,
    "desc": ""
  },
  "duration": 6000,
  "style": {
    "zIndex": 0,
    "backgroundColor": "#000000,1.00"
  },
  "transition": {
    "animation": "",
    "duration": 2000,
    "easing": "",
    "params": {
      "verticalNumber": 0,
      "horizontalNumber": 0
    }
  },
  "thumbnail": {
    "content": "files/thumb/55.jpg"
  },
  "large": {
    "content": "files/large/55.jpg"
  },
  "elements": []
}];
